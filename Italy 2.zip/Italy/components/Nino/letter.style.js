import { StyleSheet } from "react-native";
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

export const s = StyleSheet.create({
    container: { 
      flex: 1, 
      justifyContent: 'center',
    },
    row: { 
        flexDirection: "row",
    },
    container1: { 
        flex: 2, 
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: { 
        color: "white",
        fontSize: 30, 
        marginLeft: 180, 
        marginRight: 240, 
        marginTop: 30,
      },
    nonno: { 
        height: 270, 
        width: 270, 
        alignSelf: 'center',
        marginTop: 20, 
    },
    img: { 
        flex: 1, 
    },
    button: {
        height: 80, 
        width: 220, 
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'green',
        borderWidth: 2, 
        borderColor: 'red',
        borderRadius: 20, 
        margin: 10,
        marginRight: 150,
        alignSelf: 'flex-end',
    },
    box: {
        height: 80, 
        width: 470, 
        backgroundColor: 'black',
        borderColor: 'white',
        borderWidth: 2,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 20,
        margin: 5,
        alignSelf: 'flex-end',
      },
      text: { 
        color: 'white',
        fontSize: 15,
        margin: 2,
      },
      btext: {
        color: 'white',
        fontSize: 19,
      }
});