import { StyleSheet, Text, View, Dimensions, TouchableOpacity, ViewBase, Image, ImageBackground } from 'react-native';
import { s } from './ModernStart.Style';
import Constants from 'expo-constants';
import { useState } from 'react';
import tobe from '/reactnative/Italy/assets/Tobe.jpg';
import { Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

export function ModernStart() {
  const nav = useNavigation(); 
  return (
    <View style={s.container}>
      <View style={s.box}>
        <Text style={s.text}>
          You have chosen the modern day time period. In this time period, you will have to choose one of five different ways to enter the country and try to get naturalized. Before you choose a path, you will have to pick one of three characters to play as. Each characters have different aspects that will help you out on different paths you take. To start, choose one of the options below.   
          </Text> 
      </View>
        
          <TouchableOpacity onPress={() => nav.navigate("CharacterProfile1")}>
          <View style={s.button}>
            <Text style={s.btext}>
              Person One
            </Text>
          </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => nav.navigate("CharacterProfile2")}>
          <View style={s.button}>
            <Text style={s.btext}>
              Person Two  
            </Text>
          </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => nav.navigate("CharacterProfile3")}>
          <View style={s.button}>
            <Text style={s.btext}>
              Person Three 
            </Text>
          </View>
          </TouchableOpacity>
      
    </View>
  );
}