import { StyleSheet } from "react-native";
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

export const s = StyleSheet.create({
    container: { 
      flex: 1, 
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'green',
    },
    row: { 
        flexDirection: "row",
    },
    arrow: { 
        alignSelf: "flex-start",
        fontSize: 30,
        color: "white",
        margin: 40, 
    },
    title: { 
        color: "white",
        fontSize: 30, 
        marginLeft: 200, 
        marginRight: 300, 
        marginTop: 40,
      },
    nonno: { 
        height: 300, 
        width: 300, 
        alignSelf: 'center',
        margin: 10,
    },
    box: { 
        height: 280, 
        width: 350, 
        backgroundColor: 'red',
        borderColor: 'white',
        borderWidth: 2, 
        borderRadius: 50,
    },
    text: { 
        color: 'white',
        fontSize: 19,
        margin: 2,
    },
    text2: { 
        color: 'white',
        fontSize: 19,
        margin: 10,
        alignSelf: 'center',
    },
    button: { 
        borderRadius: 70, 
        height: 55, 
        width: 55, 
        borderWidth: 2, 
        borderColor: 'green',
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20, 
        marginRight: 17,
        alignSelf: 'flex-end',
    },
    btext: { 
        color: 'red',
        fontSize: 27, 
    },
});