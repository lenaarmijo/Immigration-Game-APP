import { StyleSheet, Text, View, Dimensions, TouchableOpacity, ViewBase, Image } from 'react-native';
import { s } from './CharacterTwo.style';
import Constants from 'expo-constants';
import { useState } from 'react';
import { Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import nino from '/reactnative/Italy/assets/PersonTwo.png';

export function CharacterProfile2() {
  const nav = useNavigation(); 
  return (

    <View style={s.container}>
        <View style={s.row}>
        <TouchableOpacity onPress={() => nav.navigate("ModernStart")}>
            <Feather name="arrow-left-circle" style={s.arrow} />
        </TouchableOpacity> 
        <Text style={s.title}> 
            Person Two
        </Text>
        </View>
        <View style={s.row}>
        <Image style={s.nonno} source={nino} />
        <View style={s.box}>
            <Text style={s.text2}>
            Character Profile: 
            </Text>
            <Text style={s.text}> 
                    Motivation: Modern Day Arranged Marriage 
            </Text>
            <Text style={s.text}> 
                    Asset: Pretty, College Degree, Knows English, Has a Following on Social Media
            </Text>
            <Text style={s.text}> 
                    Liabilty: Your Arranged Fiance is not Loyal, You have Children
            </Text>
            <TouchableOpacity onPress={() => nav.navigate("Start2")}>
            <View style={s.button}>
                <Text style={s.btext}>
                    Go!
                </Text>
            </View>
            </TouchableOpacity>
        </View>
        </View>
    </View>
  
  );
}