import { StyleSheet, Text, View, Dimensions, TouchableOpacity, ViewBase, Image } from 'react-native';
import { s } from './CharacterThree.style';
import Constants from 'expo-constants';
import { useState } from 'react';
import { Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import nino from '/reactnative/Italy/assets/PersonThree.png';

export function CharacterProfile3() {
  const nav = useNavigation(); 
  return (

    <View style={s.container}>
        <View style={s.row}>
        <TouchableOpacity onPress={() => nav.navigate("ModernStart")}>
            <Feather name="arrow-left-circle" style={s.arrow} />
        </TouchableOpacity> 
        <Text style={s.title}> 
            Person Three
        </Text>
        </View>
        <View style={s.row}>
        <Image style={s.nonno} source={nino} />
        <View style={s.box}>
           <Text style={s.text2}>
            Character Profile: 
            </Text>
            <Text style={s.text}> 
                    Motivation: Make Money
            </Text>
            <Text style={s.text}> 
                    Asset: Knows English, Education in Coding, Social Media
            </Text>
            <Text style={s.text}> 
                    Liabilty: Law Change, Contract is expired
            </Text>
            <TouchableOpacity onPress={() => nav.navigate("Start3")}>
            <View style={s.button}>
                <Text style={s.btext}>
                    Go!
                </Text>
            </View>
            </TouchableOpacity>
        </View>
        </View>
    </View>
  
  );
}